# Forex MT5 AutoTrade Bot (Python)

Versi Python + MetaTrader 5 dari bot autotrade kamu.

## Fitur
- Auto scan forex pairs + XAUUSD menggunakan strategi EMA + RSI + Volume Breakout + ATR
- TradingView Webhook receiver
- Telegram control lengkap (`/trade`, `/stop`, `/signal`, `/cekprofit`, dll)
- ATR TP/SL otomatis
- ROI-based exit
- Fixed margin atau risk-based position sizing
- Paper trading mode
- Support manual signal + auto trade

## Cara Menjalankan

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Setup MetaTrader 5
- Buka MT5 terminal
- Allow automated trading (Tools → Options → Expert Advisors → Allow automated trading)
- Catat **Login**, **Password**, dan **Server**

### 3. Buat file `.env`
Copy `.env.example` menjadi `.env` dan isi semua kredensial.

### 4. Jalankan bot
```bash
python main.py
```

## Catatan Penting

- Bot ini **harus dijalankan di komputer/VPS yang sama** dengan MT5 terminal (karena library MetaTrader5 berkomunikasi langsung dengan terminal).
- Untuk production, gunakan VPS Windows + MT5 + bot Python.
- Symbol harus persis seperti di Market Watch MT5 kamu (contoh: `EURUSD`, `XAUUSD` — tanpa slash).

## Perbedaan dengan versi Binance (Node.js)

| Fitur                    | Binance (Node.js)      | MT5 (Python)              |
|--------------------------|------------------------|---------------------------|
| Exchange                 | Binance Futures        | MetaTrader 5              |
| Symbol                   | BTCUSDT, XAUUSDT       | EURUSD, XAUUSD            |
| Order TP/SL              | Native Binance         | Langsung saat entry       |
| Auto scan                | Crypto only            | Forex + Gold + Indices    |
| Execution quality        | Bagus untuk crypto     | Sangat bagus untuk forex  |

## Next Steps (bisa saya tambahkan nanti)
- ROI exit monitoring loop
- Multi-timeframe confirmation
- Trailing stop
- Dashboard web sederhana

Kalau butuh tambahan fitur atau perbaikan, bilang saja!

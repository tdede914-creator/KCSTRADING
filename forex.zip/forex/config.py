from pydantic_settings import BaseSettings
from pydantic import Field, field_validator
from typing import Optional
import os

class Settings(BaseSettings):
    # ===== MT5 CONNECTION =====
    mt5_login: int = Field(0, env="MT5_LOGIN")
    mt5_password: str = Field("", env="MT5_PASSWORD")
    mt5_server: str = Field("", env="MT5_SERVER")
    mt5_path: Optional[str] = Field(None, env="MT5_PATH")

    # ===== TRADING MODE =====
    paper_trading: bool = Field(True, env="PAPER_TRADING")
    send_signal_only: bool = Field(False, env="SEND_SIGNAL_ONLY")
    auto_scan_enabled: bool = Field(True, env="AUTO_SCAN_ENABLED")

    # ===== TELEGRAM =====
    telegram_bot_token: str = Field("", env="TELEGRAM_BOT_TOKEN")
    telegram_chat_id: str = Field("", env="TELEGRAM_CHAT_ID")

    # ===== AUTO SCAN =====
    timeframe: str = Field("M15", env="TIMEFRAME")
    forex_symbols: list[str] = Field(
        default_factory=lambda: [
            "EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "USDCAD", "NZDUSD",
            "EURGBP", "EURJPY", "GBPJPY", "AUDJPY", "XAUUSD", "XAGUSD"
        ],
        env="FOREX_SYMBOLS"
    )

    min_confidence_for_signal: float = Field(70.0, env="MIN_CONFIDENCE_FOR_SIGNAL")
    max_open_positions: int = Field(2, env="MAX_OPEN_POSITIONS")
    scan_interval_seconds: int = Field(10, env="SCAN_INTERVAL_SECONDS")

    # ===== RISK MANAGEMENT =====
    use_fixed_margin: bool = Field(True, env="USE_FIXED_MARGIN")
    fixed_margin_usd: float = Field(50.0, env="FIXED_MARGIN_USD")
    risk_per_trade: float = Field(0.01, env="RISK_PER_TRADE")
    leverage: int = Field(100, env="LEVERAGE")

    # Fixed Lot
    use_fixed_lot: bool = Field(False, env="USE_FIXED_LOT")
    fixed_lot_size: float = Field(0.01, env="FIXED_LOT_SIZE")

    # ATR TP/SL
    use_atr_tp_sl: bool = Field(True, env="USE_ATR_TP_SL")
    sl_atr_multiplier: float = Field(2.5, env="SL_ATR_MULTIPLIER")
    tp_atr_multiplier: float = Field(5.0, env="TP_ATR_MULTIPLIER")

    # ROI Exit
    use_roi_exit: bool = Field(True, env="USE_ROI_EXIT")
    roi_take_profit_percent: float = Field(50.0, env="ROI_TAKE_PROFIT_PERCENT")
    roi_stop_loss_percent: float = Field(-100.0, env="ROI_STOP_LOSS_PERCENT")

    # ===== WEBHOOK =====
    enable_webhook: bool = Field(True, env="ENABLE_WEBHOOK")
    webhook_port: int = Field(3000, env="WEBHOOK_PORT")
    webhook_path: str = Field("/webhook/tv", env="WEBHOOK_PATH")
    webhook_secret: str = Field("", env="WEBHOOK_SECRET")

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8", "extra": "ignore"}


settings = Settings()


@field_validator("forex_symbols", mode="before")
@classmethod
def parse_forex_symbols(cls, v):
    if isinstance(v, str):
        v = v.strip()
        if v.startswith("["):
            import json
            return json.loads(v)
        else:
            return [s.strip() for s in v.split(",") if s.strip()]
    return v


def get_mt5_timeframe(tf: str):
    import MetaTrader5 as mt5
    tf_map = {
        "M1": mt5.TIMEFRAME_M1,
        "M5": mt5.TIMEFRAME_M5,
        "M15": mt5.TIMEFRAME_M15,
        "M30": mt5.TIMEFRAME_M30,
        "H1": mt5.TIMEFRAME_H1,
        "H4": mt5.TIMEFRAME_H4,
        "D1": mt5.TIMEFRAME_D1,
    }
    return tf_map.get(tf.upper(), mt5.TIMEFRAME_M15)
import logging
import asyncio
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes
from config import settings
from core.mt5_connector import MT5Connector
from core.strategy import ForexStrategy
from datetime import datetime

logger = logging.getLogger(__name__)

class TelegramHandler:
    def __init__(self, mt5: MT5Connector, strategy: ForexStrategy):
        self.mt5 = mt5
        self.strategy = strategy
        self.trading_enabled = False
        self.last_signal = None

        self.app = Application.builder().token(settings.telegram_bot_token).build()

        # Register commands
        self.app.add_handler(CommandHandler("start", self.cmd_start))
        self.app.add_handler(CommandHandler("trade", self.cmd_trade))
        self.app.add_handler(CommandHandler("stop", self.cmd_stop))
        self.app.add_handler(CommandHandler("cekprofit", self.cmd_cekprofit))
        self.app.add_handler(CommandHandler("closeall", self.cmd_closeall))
        self.app.add_handler(CommandHandler("signal", self.cmd_signal))
        self.app.add_handler(CommandHandler("lastsignal", self.cmd_lastsignal))

    async def start_polling(self):
        logger.info("Telegram bot polling started...")
        await self.app.initialize()
        await self.app.start()
        await self.app.updater.start_polling()
        # Keep running
        while True:
            await asyncio.sleep(3600)

    async def cmd_start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await update.message.reply_text(
            "🤖 *Forex MT5 AutoTrade Bot*\n\n"
            "Commands:\n"
            "/trade - Mulai auto scan & trade\n"
            "/stop - Hentikan auto trade\n"
            "/signal EURUSD - Kirim signal manual\n"
            "/lastsignal - Lihat sinyal terakhir\n"
            "/cekprofit - Cek balance & posisi\n"
            "/closeall - Tutup semua posisi",
            parse_mode="Markdown"
        )

    async def cmd_trade(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        self.trading_enabled = True
        await update.message.reply_text("✅ *AUTO TRADE AKTIF*\nBot akan scan dan eksekusi order otomatis.", parse_mode="Markdown")

    async def cmd_stop(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        self.trading_enabled = False
        await update.message.reply_text("🛑 *AUTO TRADE DIMATIKAN*", parse_mode="Markdown")

    async def cmd_cekprofit(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        balance = self.mt5.get_account_balance()
        positions = self.mt5.get_open_positions()

        text = f"💰 *Balance:* {balance:.2f}\n"
        text += f"Posisi aktif: {len(positions)}\n\n"

        if positions:
            for p in positions:
                text += f"• {p['symbol']} | {p['type']} | Vol={p['volume']} | PnL={p['profit']:.2f}\n"

        await update.message.reply_text(text, parse_mode="Markdown")

    async def cmd_closeall(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        closed = self.mt5.close_all_positions()
        await update.message.reply_text(f"✅ Menutup {closed} posisi.")

    async def cmd_signal(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        args = context.args
        if not args:
            await update.message.reply_text("Gunakan: `/signal EURUSD` atau `/signal XAUUSD`", parse_mode="Markdown")
            return

        symbol = args[0].upper()
        # For simplicity, we just save it as last signal (manual mode)
        self.last_signal = {
            "symbol": symbol,
            "direction": None,
            "timeframe": settings.timeframe,
            "reason": "Manual via Telegram",
            "received_at": datetime.now()
        }
        await update.message.reply_text(f"✅ Signal untuk *{symbol}* disimpan.\nSilakan trade manual atau gunakan auto mode.", parse_mode="Markdown")

    async def cmd_lastsignal(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not self.last_signal:
            await update.message.reply_text("Belum ada sinyal.")
            return

        s = self.last_signal
        text = f"📡 *Sinyal Terakhir*\n\nSymbol: `{s['symbol']}`\n"
        if s.get('direction'):
            text += f"Direction: {s['direction']}\n"
        text += f"Timeframe: {s.get('timeframe', '-')}\nReason: {s.get('reason', '-')}"
        await update.message.reply_text(text, parse_mode="Markdown")

    async def send_signal_notification(self, signal: dict):
        text = (
            f"🟢 *SIGNAL FOREX*\n\n"
            f"Pair: `{signal['symbol']}`\n"
            f"Direction: {signal['direction']}\n"
            f"Confidence: {signal['confidence']}%\n"
            f"Entry approx: {signal['close']:.5f}\n"
            f"ATR: {signal['atr']:.5f}\n"
            f"Reason: {signal['reason']}"
        )
        await self.app.bot.send_message(chat_id=settings.telegram_chat_id, text=text, parse_mode="Markdown")

    async def execute_trade(self, signal: dict):
        """Execute trade on MT5"""
        from core.risk_manager import calculate_tp_sl, calculate_lot_size

        symbol = signal["symbol"]
        direction = signal["direction"]
        entry = signal["close"]
        atr = signal["atr"]

        tp, sl = calculate_tp_sl(direction, entry, atr)

        balance = self.mt5.get_account_balance()
        lot = calculate_lot_size(self.mt5, symbol, entry, sl, balance)

        result = self.mt5.place_market_order(
            symbol=symbol,
            direction=direction,
            volume=lot,
            sl=sl,
            tp=tp,
            comment="AutoTrade Python MT5"
        )

        if result:
            await self.send_signal_notification(signal)
            await self.app.bot.send_message(
                chat_id=settings.telegram_chat_id,
                text=f"✅ ORDER EXECUTED\n{symbol} {direction} | Lot: {lot}\nSL: {sl:.5f} | TP: {tp:.5f}"
            )

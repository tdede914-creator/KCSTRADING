from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse
import uvicorn
import asyncio
from config import settings
from core.mt5_connector import MT5Connector
from core.strategy import ForexStrategy
from handlers.telegram_handler import TelegramHandler
import logging

logger = logging.getLogger(__name__)

app = FastAPI(title="Forex MT5 Webhook")

mt5_instance: MT5Connector = None
strategy_instance: ForexStrategy = None
telegram_instance: TelegramHandler = None


def set_instances(mt5: MT5Connector, strategy: ForexStrategy, telegram: TelegramHandler):
    global mt5_instance, strategy_instance, telegram_instance
    mt5_instance = mt5
    strategy_instance = strategy
    telegram_instance = telegram


@app.post(settings.webhook_path)
async def tradingview_webhook(request: Request):
    try:
        payload = await request.json()

        # Optional secret check
        if settings.webhook_secret:
            secret = request.headers.get("x-webhook-secret") or payload.get("secret", "")
            if secret != settings.webhook_secret:
                raise HTTPException(status_code=403, detail="Invalid secret")

        symbol = payload.get("symbol") or payload.get("ticker") or payload.get("pair")
        direction = (payload.get("direction") or payload.get("action") or "").upper()

        if not symbol:
            return JSONResponse({"error": "No symbol"}, status_code=400)

        # Normalize direction
        if direction in ["BUY", "LONG"]:
            direction = "LONG"
        elif direction in ["SELL", "SHORT"]:
            direction = "SHORT"
        else:
            direction = None

        signal = {
            "symbol": str(symbol).upper(),
            "direction": direction,
            "close": float(payload.get("price") or payload.get("close") or 0),
            "atr": float(payload.get("atr") or 0),
            "confidence": float(payload.get("confidence") or 80),
            "reason": payload.get("reason") or payload.get("message") or "TradingView Webhook",
            "timeframe": payload.get("timeframe") or settings.timeframe,
        }

        # Save as last signal
        if telegram_instance:
            telegram_instance.last_signal = signal

        # Send notification
        if telegram_instance:
            await telegram_instance.send_signal_notification(signal)

        # Auto execute if not in signal-only mode
        if not settings.send_signal_only and telegram_instance and telegram_instance.trading_enabled:
            if direction in ["LONG", "SHORT"]:
                await telegram_instance.execute_trade(signal)

        return {"status": "ok", "symbol": symbol}

    except Exception as e:
        logger.error(f"Webhook error: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)


@app.get("/health")
async def health():
    return {"status": "ok", "time": str(asyncio.get_event_loop().time())}


async def start_webhook_server(mt5, strategy, telegram):
    set_instances(mt5, strategy, telegram)
    config = uvicorn.Config(app, host="0.0.0.0", port=settings.webhook_port, log_level="info")
    server = uvicorn.Server(config)
    await server.serve()

import asyncio
import logging
from datetime import datetime
from config import settings
from core.mt5_connector import MT5Connector
from core.strategy import ForexStrategy
from handlers.telegram_handler import TelegramHandler
from handlers.webhook_handler import start_webhook_server

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)
logger = logging.getLogger(__name__)


async def main():
    logger.info("🚀 Starting Forex MT5 AutoTrade Bot...")

    # Connect to MT5
    mt5 = MT5Connector()
    if not mt5.connect():
        logger.error("Failed to connect to MT5. Exiting.")
        return

    strategy = ForexStrategy(mt5)
    telegram = TelegramHandler(mt5, strategy)

    # Start Telegram polling in background
    asyncio.create_task(telegram.start_polling())

    # Start Webhook server (non-blocking)
    if settings.enable_webhook:
        asyncio.create_task(start_webhook_server(mt5, strategy, telegram))

    logger.info("Bot is running. Press Ctrl+C to stop.")

    # Main auto-scan loop
    while True:
        try:
            if not settings.auto_scan_enabled or not telegram.trading_enabled:
                await asyncio.sleep(settings.scan_interval_seconds)
                continue

            open_count = mt5.get_open_positions_count()
            if open_count >= settings.max_open_positions:
                await asyncio.sleep(settings.scan_interval_seconds)
                continue

            best_signal = strategy.scan_best_symbol()
            if best_signal:
                if settings.send_signal_only:
                    await telegram.send_signal_notification(best_signal)
                else:
                    await telegram.execute_trade(best_signal)

            await asyncio.sleep(settings.scan_interval_seconds)

        except KeyboardInterrupt:
            break
        except Exception as e:
            logger.error(f"Main loop error: {e}")
            await asyncio.sleep(10)

    mt5.disconnect()
    logger.info("Bot stopped.")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nBot stopped by user.")

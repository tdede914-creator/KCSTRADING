from config import settings
from core.mt5_connector import MT5Connector

def calculate_tp_sl(direction: str, entry_price: float, atr: float) -> tuple[float, float]:
    if direction == "LONG":
        tp = entry_price + (settings.tp_atr_multiplier * atr)
        sl = entry_price - (settings.sl_atr_multiplier * atr)
    else:
        tp = entry_price - (settings.tp_atr_multiplier * atr)
        sl = entry_price + (settings.sl_atr_multiplier * atr)
    return round(tp, 5), round(sl, 5)


def calculate_lot_size(mt5: MT5Connector, symbol: str, entry_price: float, sl_price: float, balance: float) -> float:
    return mt5.calculate_position_size(symbol, entry_price, sl_price, balance)

import pandas as pd
from typing import Optional, Dict, List
from config import settings, get_mt5_timeframe
from core.mt5_connector import MT5Connector
from core.indicators import add_indicators
import logging

logger = logging.getLogger(__name__)


class ForexStrategy:
    def __init__(self, mt5: MT5Connector):
        self.mt5 = mt5
        self.timeframe = get_mt5_timeframe(settings.timeframe)
        self.htf = get_mt5_timeframe("H1")

    def get_htf_structure(self, symbol: str) -> Dict:
        """Analisis struktur di Higher Timeframe (H1)"""
        try:
            df = self.mt5.get_rates(symbol, self.htf, count=500)
            if df is None or len(df) < 300:
                return {"bias": "NEUTRAL", "support": None, "resistance": None}

            data = add_indicators(df)
            last = data.iloc[-1]

            # Tentukan bias
            if last.ema50 > last.ema200:
                bias = "BULLISH"
            elif last.ema50 < last.ema200:
                bias = "BEARISH"
            else:
                bias = "NEUTRAL"

            # Ambil swing high & low sederhana (50 candle terakhir)
            recent_high = data['high'].iloc[-50:].max()
            recent_low = data['low'].iloc[-50:].min()

            return {
                "bias": bias,
                "support": recent_low,
                "resistance": recent_high
            }
        except Exception as e:
            logger.warning(f"HTF Structure error on {symbol}: {e}")
            return {"bias": "NEUTRAL", "support": None, "resistance": None}

    def scan_best_symbol(self) -> Optional[Dict]:
        candidates = []

        for symbol in settings.forex_symbols:
            try:
                # Cek market open
                symbol_info = self.mt5.get_symbol_info(symbol)
                if symbol_info is None or symbol_info.trade_mode != 4:
                    continue

                # === Higher Timeframe Structure ===
                htf = self.get_htf_structure(symbol)
                if htf["bias"] == "NEUTRAL":
                    continue

                # Ambil data M5/M15
                df = self.mt5.get_rates(symbol, self.timeframe, count=300)
                if df is None or len(df) < 220:
                    continue

                data = add_indicators(df)
                last = data.iloc[-1]

                # === Pullback Logic ===
                near_support = False
                near_resistance = False

                if htf["support"] and last.close <= htf["support"] * 1.001:
                    near_support = True
                if htf["resistance"] and last.close >= htf["resistance"] * 0.999:
                    near_resistance = True

                # === Scoring dengan Konfluensi ===
                long_score = 0
                short_score = 0
                reasons = []

                # HTF Bias
                if htf["bias"] == "BULLISH":
                    long_score += 30
                    reasons.append("HTF Bullish")
                elif htf["bias"] == "BEARISH":
                    short_score += 30
                    reasons.append("HTF Bearish")

                # Pullback ke S/R
                if near_support and htf["bias"] == "BULLISH":
                    long_score += 25
                    reasons.append("Pullback to HTF Support")
                if near_resistance and htf["bias"] == "BEARISH":
                    short_score += 25
                    reasons.append("Pullback to HTF Resistance")

                # EMA & Price Action
                if last.ema50 > last.ema200:
                    long_score += 15
                elif last.ema50 < last.ema200:
                    short_score += 15

                if last.close > last.ema50:
                    long_score += 10
                elif last.close < last.ema50:
                    short_score += 10

                # RSI
                if 45 <= last.rsi <= 70:
                    long_score += 10
                elif 30 <= last.rsi <= 55:
                    short_score += 10

                # Volume
                if last.vol_ma20 and last.volume > last.vol_ma20:
                    long_score += 10
                    short_score += 10

                # Final Decision
                if long_score >= 55 and htf["bias"] == "BULLISH":
                    candidates.append({
                        "symbol": symbol,
                        "direction": "LONG",
                        "confidence": long_score,
                        "close": last.close,
                        "atr": last.atr,
                        "reason": ", ".join(reasons),
                        "htf_bias": htf["bias"]
                    })

                if short_score >= 55 and htf["bias"] == "BEARISH":
                    candidates.append({
                        "symbol": symbol,
                        "direction": "SHORT",
                        "confidence": short_score,
                        "close": last.close,
                        "atr": last.atr,
                        "reason": ", ".join(reasons),
                        "htf_bias": htf["bias"]
                    })

            except Exception as e:
                logger.warning(f"[SCAN ERROR] {symbol}: {e}")

        if not candidates:
            return None

        candidates.sort(key=lambda x: x["confidence"], reverse=True)
        best = candidates[0]
        logger.info(f"[PROFESSIONAL SCAN] {best['symbol']} {best['direction']} | Conf: {best['confidence']}% | {best['reason']}")
        return best
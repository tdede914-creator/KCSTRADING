import pandas as pd
import pandas_ta as ta
from typing import Optional

def add_indicators(df: pd.DataFrame) -> pd.DataFrame:
    """Add EMA, RSI, ATR and other indicators"""
    if len(df) < 220:
        return df

    df = df.copy()

    # EMA
    df['ema50'] = ta.ema(df['close'], length=50)
    df['ema200'] = ta.ema(df['close'], length=200)

    # RSI
    df['rsi'] = ta.rsi(df['close'], length=14)

    # ATR
    df['atr'] = ta.atr(df['high'], df['low'], df['close'], length=14)

    # Volume MA
    if 'volume' in df.columns:
        df['vol_ma20'] = ta.sma(df['volume'], length=20)
    else:
        df['vol_ma20'] = None

    # Highest / Lowest of last 20 candles
    df['high20'] = df['high'].rolling(window=20).max().shift(1)
    df['low20'] = df['low'].rolling(window=20).min().shift(1)

    return df


def score_market(df: pd.DataFrame) -> dict:
    """Score the market for LONG / SHORT signal (same logic as original bot)"""
    if len(df) < 220:
        return {"direction": "NO_TRADE", "confidence": 0, "reason": "Not enough data"}

    data = add_indicators(df)
    last = data.iloc[-1]
    prev = data.iloc[-2]

    if pd.isna(last.ema50) or pd.isna(last.ema200) or pd.isna(last.rsi) or pd.isna(last.atr):
        return {"direction": "NO_TRADE", "confidence": 0, "reason": "Indicators not ready"}

    long_score = 0
    short_score = 0
    reasons_long = []
    reasons_short = []

    # EMA Trend
    if last.ema50 > last.ema200:
        long_score += 25
        reasons_long.append("EMA50 > EMA200")
    elif last.ema50 < last.ema200:
        short_score += 25
        reasons_short.append("EMA50 < EMA200")

    # Price vs EMA50
    if last.close > last.ema50:
        long_score += 20
        reasons_long.append("Price > EMA50")
    elif last.close < last.ema50:
        short_score += 20
        reasons_short.append("Price < EMA50")

    # RSI
    if 50 <= last.rsi <= 75:
        long_score += 20
        reasons_long.append(f"RSI bullish ({last.rsi:.1f})")
    elif 25 <= last.rsi <= 50:
        short_score += 20
        reasons_short.append(f"RSI bearish ({last.rsi:.1f})")

    # Volume
    if last.vol_ma20 and last.volume > last.vol_ma20:
        long_score += 15
        short_score += 15
        reasons_long.append("Volume > MA20")
        reasons_short.append("Volume > MA20")

    # Breakout
    if last.close > prev.high20:
        long_score += 20
        reasons_long.append("Breakout High 20")
    elif last.close < prev.low20:
        short_score += 20
        reasons_short.append("Breakdown Low 20")

    if long_score > short_score:
        return {
            "direction": "LONG",
            "confidence": long_score,
            "long_score": long_score,
            "short_score": short_score,
            "close": last.close,
            "atr": last.atr,
            "rsi": last.rsi,
            "reason": ", ".join(reasons_long)
        }
    elif short_score > long_score:
        return {
            "direction": "SHORT",
            "confidence": short_score,
            "long_score": long_score,
            "short_score": short_score,
            "close": last.close,
            "atr": last.atr,
            "rsi": last.rsi,
            "reason": ", ".join(reasons_short)
        }
    else:
        return {
            "direction": "NO_TRADE",
            "confidence": 0,
            "reason": "Scores balanced"
        }

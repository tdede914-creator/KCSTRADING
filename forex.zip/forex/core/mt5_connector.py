import MetaTrader5 as mt5
import pandas as pd
from datetime import datetime
from typing import Optional, List, Dict, Any
from config import settings
import logging

logger = logging.getLogger(__name__)


class MT5Connector:
    def __init__(self):
        self.connected = False
        self.account_info = None

    def connect(self) -> bool:
        """Connect to MetaTrader 5 terminal"""
        if settings.mt5_path:
            initialized = mt5.initialize(path=settings.mt5_path)
        else:
            initialized = mt5.initialize()

        if not initialized:
            logger.error(f"MT5 initialize() failed, error code = {mt5.last_error()}")
            return False

        if settings.mt5_login != 0:
            authorized = mt5.login(
                login=settings.mt5_login,
                password=settings.mt5_password,
                server=settings.mt5_server
            )
            if not authorized:
                logger.error(f"MT5 login failed: {mt5.last_error()}")
                mt5.shutdown()
                return False

        self.account_info = mt5.account_info()
        if self.account_info is None:
            logger.error("Failed to get account info")
            return False

        self.connected = True
        logger.info(f"✅ Connected to MT5 | Account: {self.account_info.login} | Server: {self.account_info.server}")
        logger.info(f"Balance: {self.account_info.balance} | Equity: {self.account_info.equity}")
        return True

    def disconnect(self):
        mt5.shutdown()
        self.connected = False
        logger.info("MT5 disconnected")

    def get_account_balance(self) -> float:
        info = mt5.account_info()
        return float(info.balance) if info else 0.0

    def get_open_positions(self) -> List[Dict]:
        positions = mt5.positions_get()
        if positions is None:
            return []
        return [self._position_to_dict(p) for p in positions]

    def get_open_positions_count(self) -> int:
        return len(self.get_open_positions())

    def _position_to_dict(self, pos) -> Dict:
        return {
            "ticket": pos.ticket,
            "symbol": pos.symbol,
            "type": "LONG" if pos.type == mt5.POSITION_TYPE_BUY else "SHORT",
            "volume": pos.volume,
            "price_open": pos.price_open,
            "sl": pos.sl,
            "tp": pos.tp,
            "profit": pos.profit,
            "swap": pos.swap,
            "comment": pos.comment,
        }

    def get_symbol_info(self, symbol: str):
        return mt5.symbol_info(symbol)

    def get_rates(self, symbol: str, timeframe, count: int = 300) -> Optional[pd.DataFrame]:
        """Fetch OHLCV data"""
        rates = mt5.copy_rates_from_pos(symbol, timeframe, 0, count)
        if rates is None or len(rates) == 0:
            return None

        df = pd.DataFrame(rates)
        df['time'] = pd.to_datetime(df['time'], unit='s')
        df.rename(columns={
            'open': 'open',
            'high': 'high',
            'low': 'low',
            'close': 'close',
            'tick_volume': 'volume'
        }, inplace=True)
        return df[['time', 'open', 'high', 'low', 'close', 'volume']]

    def place_market_order(
        self,
        symbol: str,
        direction: str,
        volume: float,
        sl: Optional[float] = None,
        tp: Optional[float] = None,
        comment: str = "AutoTrade MT5"
    ) -> Optional[Dict]:
        if settings.paper_trading:
            logger.info(f"[PAPER] Would place {direction} {volume} {symbol}")
            return {"retcode": 10009, "comment": "PAPER_TRADING", "symbol": symbol}

        symbol_info = mt5.symbol_info(symbol)
        if symbol_info is None:
            logger.error(f"Symbol {symbol} not found")
            return None

        if not symbol_info.visible:
            mt5.symbol_select(symbol, True)

        order_type = mt5.ORDER_TYPE_BUY if direction == "LONG" else mt5.ORDER_TYPE_SELL
        price = mt5.symbol_info_tick(symbol).ask if direction == "LONG" else mt5.symbol_info_tick(symbol).bid

        # === Pilih filling mode yang didukung ===
        filling_mode = 0
        if symbol_info.filling_mode & mt5.ORDER_FILLING_FOK:
            filling_mode = mt5.ORDER_FILLING_FOK
        elif symbol_info.filling_mode & mt5.ORDER_FILLING_IOC:
            filling_mode = mt5.ORDER_FILLING_IOC
        else:
            filling_mode = mt5.ORDER_FILLING_RETURN

        request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": symbol,
            "volume": volume,
            "type": order_type,
            "price": price,
            "sl": sl if sl else 0.0,
            "tp": tp if tp else 0.0,
            "deviation": 20,
            "magic": 123456,
            "comment": comment,
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": filling_mode,
        }

        result = mt5.order_send(request)
        if result.retcode != mt5.TRADE_RETCODE_DONE:
            logger.error(f"Order failed: {result.retcode} - {result.comment}")
            return None

        logger.info(f"✅ Order sent: {direction} {volume} {symbol}")
        return {
            "retcode": result.retcode,
            "order": result.order,
            "deal": result.deal,
            "volume": result.volume,
            "price": result.price,
            "comment": result.comment
        }

    def close_position(self, position: Dict) -> bool:
        if settings.paper_trading:
            logger.info(f"[PAPER] Would close position {position['ticket']} {position['symbol']}")
            return True

        symbol = position["symbol"]
        volume = position["volume"]
        order_type = mt5.ORDER_TYPE_SELL if position["type"] == "LONG" else mt5.ORDER_TYPE_BUY
        price = mt5.symbol_info_tick(symbol).bid if position["type"] == "LONG" else mt5.symbol_info_tick(symbol).ask

        request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": symbol,
            "volume": volume,
            "type": order_type,
            "position": position["ticket"],
            "price": price,
            "deviation": 20,
            "magic": 123456,
            "comment": "Close by bot",
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC,
        }

        result = mt5.order_send(request)
        return result.retcode == mt5.TRADE_RETCODE_DONE

    def close_all_positions(self) -> int:
        positions = self.get_open_positions()
        closed = 0
        for pos in positions:
            if self.close_position(pos):
                closed += 1
        return closed

    def calculate_position_size(self, symbol: str, entry_price: float, sl_price: float, balance: float) -> float:
        """Calculate lot size. Support fixed lot, fixed margin, or risk-based."""
        # === Prioritas 1: Fixed Lot ===
        if settings.use_fixed_lot:
            return max(settings.fixed_lot_size, 0.01)

        symbol_info = mt5.symbol_info(symbol)
        if not symbol_info:
            return 0.01

        if settings.use_fixed_margin:
            contract_size = symbol_info.trade_contract_size
            leverage = settings.leverage
            lot = (settings.fixed_margin_usd * leverage) / (entry_price * contract_size)
            return max(round(lot, 2), 0.01)

        # Risk-based
        risk_amount = balance * settings.risk_per_trade
        sl_distance = abs(entry_price - sl_price)
        if sl_distance == 0:
            return 0.01

        lot = risk_amount / (sl_distance * symbol_info.trade_contract_size)
        return max(round(lot, 2), 0.01)